/**
 * Form validation functionality for health coaching application
 * Provides validation for user registration, health profile, and progress tracking forms
 */

document.addEventListener('DOMContentLoaded', function() {
    // Find any forms that need validation
    const forms = document.querySelectorAll('form');
    
    // Add validation to each form
    forms.forEach(form => {
        // Add validation event listeners
        form.addEventListener('submit', validateForm);
        
        // Add input event listeners for real-time validation feedback
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateInput(this);
            });
            
            // Special handling for range inputs to update display values
            if (input.type === 'range') {
                const id = input.id;
                const valueDisplay = document.getElementById(`${id}_value`);
                
                if (valueDisplay) {
                    input.addEventListener('input', function() {
                        valueDisplay.textContent = this.value;
                    });
                }
            }
        });
    });
    
    // Initialize any form-specific validations based on form ID
    const intakeForm = document.getElementById('intakeForm');
    if (intakeForm) {
        initializeIntakeFormValidation(intakeForm);
    }
});

/**
 * Validate an entire form before submission
 * @param {Event} event - The form submission event
 */
function validateForm(event) {
    const form = event.target;
    const inputs = form.querySelectorAll('input, select, textarea');
    let isValid = true;
    
    // Validate each input
    inputs.forEach(input => {
        if (input.hasAttribute('required') || input.value.trim() !== '') {
            const inputValid = validateInput(input);
            isValid = isValid && inputValid;
        }
    });
    
    // Special form-specific validations
    if (form.id === 'intakeForm') {
        // Additional validation for health intake form
        const ageValid = validateAgeInput(form.querySelector('#age'));
        const heightValid = validateHeightInput(form.querySelector('#height'));
        const weightValid = validateWeightInput(form.querySelector('#weight'));
        
        isValid = isValid && ageValid && heightValid && weightValid;
    }
    
    // Prevent submission if invalid
    if (!isValid) {
        event.preventDefault();
        // Scroll to the first invalid input
        const firstInvalid = form.querySelector('.is-invalid');
        if (firstInvalid) {
            firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
}

/**
 * Validate a single input element
 * @param {HTMLElement} input - The input element to validate
 * @returns {boolean} Whether the input is valid
 */
function validateInput(input) {
    // Skip disabled inputs or those without validation rules
    if (input.disabled || (!input.required && input.value.trim() === '')) {
        removeValidationStyles(input);
        return true;
    }
    
    // Get the input value and type
    const value = input.value.trim();
    const type = input.type;
    const id = input.id;
    
    // Common validation - required fields
    if (input.required && value === '') {
        setInvalidWithFeedback(input, 'This field is required');
        return false;
    }
    
    // Type-specific validation
    switch (type) {
        case 'email':
            return validateEmailInput(input);
        case 'password':
            return validatePasswordInput(input);
        case 'number':
            return validateNumberInput(input);
        default:
            // Other input-specific validation based on ID
            if (id === 'age') {
                return validateAgeInput(input);
            } else if (id === 'height') {
                return validateHeightInput(input);
            } else if (id === 'weight') {
                return validateWeightInput(input);
            } else if (id === 'username') {
                return validateUsernameInput(input);
            }
    }
    
    // If we got here, input is valid
    setValid(input);
    return true;
}

/**
 * Set an input as invalid with custom feedback
 * @param {HTMLElement} input - The input element
 * @param {string} message - The error message
 */
function setInvalidWithFeedback(input, message) {
    // Add invalid class
    input.classList.add('is-invalid');
    input.classList.remove('is-valid');
    
    // Create or update feedback message
    let feedback = input.nextElementSibling;
    if (!feedback || !feedback.classList.contains('invalid-feedback')) {
        feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        input.parentNode.insertBefore(feedback, input.nextSibling);
    }
    
    feedback.textContent = message;
}

/**
 * Set an input as valid
 * @param {HTMLElement} input - The input element
 */
function setValid(input) {
    input.classList.remove('is-invalid');
    input.classList.add('is-valid');
    
    // Remove any feedback message
    const feedback = input.nextElementSibling;
    if (feedback && feedback.classList.contains('invalid-feedback')) {
        feedback.textContent = '';
    }
}

/**
 * Remove all validation styles from an input
 * @param {HTMLElement} input - The input element
 */
function removeValidationStyles(input) {
    input.classList.remove('is-invalid');
    input.classList.remove('is-valid');
    
    // Remove any feedback message
    const feedback = input.nextElementSibling;
    if (feedback && feedback.classList.contains('invalid-feedback')) {
        feedback.textContent = '';
    }
}

/**
 * Validate email input
 * @param {HTMLElement} input - The email input element
 * @returns {boolean} Whether the email is valid
 */
function validateEmailInput(input) {
    const value = input.value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    if (!emailRegex.test(value)) {
        setInvalidWithFeedback(input, 'Please enter a valid email address');
        return false;
    }
    
    setValid(input);
    return true;
}

/**
 * Validate password input
 * @param {HTMLElement} input - The password input element
 * @returns {boolean} Whether the password is valid
 */
function validatePasswordInput(input) {
    const value = input.value;
    
    if (value.length < 6) {
        setInvalidWithFeedback(input, 'Password must be at least 6 characters');
        return false;
    }
    
    setValid(input);
    return true;
}

/**
 * Validate numeric input
 * @param {HTMLElement} input - The number input element
 * @returns {boolean} Whether the number is valid
 */
function validateNumberInput(input) {
    const value = input.value.trim();
    
    if (value === '') {
        if (input.required) {
            setInvalidWithFeedback(input, 'This field is required');
            return false;
        }
        return true;
    }
    
    const numberValue = parseFloat(value);
    
    if (isNaN(numberValue)) {
        setInvalidWithFeedback(input, 'Please enter a valid number');
        return false;
    }
    
    const min = input.hasAttribute('min') ? parseFloat(input.getAttribute('min')) : null;
    const max = input.hasAttribute('max') ? parseFloat(input.getAttribute('max')) : null;
    
    if (min !== null && numberValue < min) {
        setInvalidWithFeedback(input, `Value must be at least ${min}`);
        return false;
    }
    
    if (max !== null && numberValue > max) {
        setInvalidWithFeedback(input, `Value must be no more than ${max}`);
        return false;
    }
    
    setValid(input);
    return true;
}

/**
 * Validate age input
 * @param {HTMLElement} input - The age input element
 * @returns {boolean} Whether the age is valid
 */
function validateAgeInput(input) {
    const value = input.value.trim();
    
    if (value === '') {
        if (input.required) {
            setInvalidWithFeedback(input, 'Age is required');
            return false;
        }
        return true;
    }
    
    const age = parseInt(value);
    
    if (isNaN(age)) {
        setInvalidWithFeedback(input, 'Please enter a valid age');
        return false;
    }
    
    if (age < 18) {
        setInvalidWithFeedback(input, 'You must be at least 18 years old');
        return false;
    }
    
    if (age > 120) {
        setInvalidWithFeedback(input, 'Please enter a valid age');
        return false;
    }
    
    setValid(input);
    return true;
}

/**
 * Validate height input
 * @param {HTMLElement} input - The height input element
 * @returns {boolean} Whether the height is valid
 */
function validateHeightInput(input) {
    const value = input.value.trim();
    
    if (value === '') {
        if (input.required) {
            setInvalidWithFeedback(input, 'Height is required');
            return false;
        }
        return true;
    }
    
    const height = parseFloat(value);
    
    if (isNaN(height)) {
        setInvalidWithFeedback(input, 'Please enter a valid height');
        return false;
    }
    
    if (height < 100) {
        setInvalidWithFeedback(input, 'Height seems too low (min 100 cm)');
        return false;
    }
    
    if (height > 250) {
        setInvalidWithFeedback(input, 'Height seems too high (max 250 cm)');
        return false;
    }
    
    setValid(input);
    return true;
}

/**
 * Validate weight input
 * @param {HTMLElement} input - The weight input element
 * @returns {boolean} Whether the weight is valid
 */
function validateWeightInput(input) {
    const value = input.value.trim();
    
    if (value === '') {
        if (input.required) {
            setInvalidWithFeedback(input, 'Weight is required');
            return false;
        }
        return true;
    }
    
    const weight = parseFloat(value);
    
    if (isNaN(weight)) {
        setInvalidWithFeedback(input, 'Please enter a valid weight');
        return false;
    }
    
    if (weight < 30) {
        setInvalidWithFeedback(input, 'Weight seems too low (min 30 kg)');
        return false;
    }
    
    if (weight > 300) {
        setInvalidWithFeedback(input, 'Weight seems too high (max 300 kg)');
        return false;
    }
    
    setValid(input);
    return true;
}

/**
 * Validate username input
 * @param {HTMLElement} input - The username input element
 * @returns {boolean} Whether the username is valid
 */
function validateUsernameInput(input) {
    const value = input.value.trim();
    
    if (value.length < 3) {
        setInvalidWithFeedback(input, 'Username must be at least 3 characters');
        return false;
    }
    
    if (value.length > 20) {
        setInvalidWithFeedback(input, 'Username must be less than 20 characters');
        return false;
    }
    
    // Allow only alphanumeric characters and underscore
    const usernameRegex = /^[a-zA-Z0-9_]+$/;
    if (!usernameRegex.test(value)) {
        setInvalidWithFeedback(input, 'Username can only contain letters, numbers, and underscores');
        return false;
    }
    
    setValid(input);
    return true;
}

/**
 * Set up specialized validation for the health intake form
 * @param {HTMLElement} form - The intake form element
 */
function initializeIntakeFormValidation(form) {
    // Calculate BMI when height or weight changes
    const heightInput = form.querySelector('#height');
    const weightInput = form.querySelector('#weight');
    
    if (heightInput && weightInput) {
        const calculateBMI = function() {
            const height = parseFloat(heightInput.value);
            const weight = parseFloat(weightInput.value);
            
            if (!isNaN(height) && !isNaN(weight) && height > 0) {
                const heightMeters = height / 100;
                const bmi = weight / (heightMeters * heightMeters);
                
                // You could display this BMI value somewhere if needed
                console.log(`Calculated BMI: ${bmi.toFixed(1)}`);
            }
        };
        
        heightInput.addEventListener('change', calculateBMI);
        weightInput.addEventListener('change', calculateBMI);
    }
}
