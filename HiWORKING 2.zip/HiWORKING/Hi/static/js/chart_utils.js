/**
 * Chart utilities for health coaching application
 * Provides helper functions for chart creation and management
 */

/**
 * Create a responsive configuration for charts with consistent styling
 * @param {string} type - The type of chart (line, bar, pie, etc.)
 * @param {object} data - The chart data (labels and datasets)
 * @param {object} options - Additional options to merge with defaults
 * @returns {object} Chart configuration object
 */
function createChartConfig(type, data, options = {}) {
    // Default chart configuration for dark theme
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                ticks: {
                    color: '#adb5bd'
                },
                grid: {
                    color: 'rgba(255, 255, 255, 0.05)'
                }
            },
            x: {
                ticks: {
                    color: '#adb5bd'
                },
                grid: {
                    color: 'rgba(255, 255, 255, 0.05)'
                }
            }
        },
        plugins: {
            legend: {
                labels: {
                    color: '#adb5bd'
                }
            },
            tooltip: {
                backgroundColor: 'rgba(33, 37, 41, 0.9)',
                titleColor: '#fff',
                bodyColor: '#fff',
                borderColor: 'rgba(255, 255, 255, 0.1)',
                borderWidth: 1
            }
        }
    };

    // Merge with provided options
    const mergedOptions = {
        ...defaultOptions,
        ...options
    };

    return {
        type,
        data,
        options: mergedOptions
    };
}

/**
 * Format date values for chart display
 * @param {string|Date} dateString - Date string or object to format
 * @param {string} format - Format style ('short', 'medium', 'long')
 * @returns {string} Formatted date string
 */
function formatChartDate(dateString, format = 'short') {
    const date = new Date(dateString);
    
    if (isNaN(date.getTime())) {
        return dateString; // Return original if invalid
    }
    
    switch (format) {
        case 'short':
            return date.toLocaleDateString();
        case 'medium':
            return date.toLocaleDateString(undefined, { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            });
        case 'long':
            return date.toLocaleDateString(undefined, { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
        default:
            return date.toLocaleDateString();
    }
}

/**
 * Generate a gradient for chart backgrounds
 * @param {CanvasRenderingContext2D} ctx - Canvas context
 * @param {string} colorStart - Starting color (hex or rgba)
 * @param {string} colorEnd - Ending color (hex or rgba)
 * @param {boolean} vertical - Direction of gradient (true for vertical)
 * @returns {CanvasGradient} Gradient object for use in chart
 */
function createChartGradient(ctx, colorStart, colorEnd, vertical = false) {
    let gradient;
    
    if (vertical) {
        gradient = ctx.createLinearGradient(0, 0, 0, ctx.canvas.height);
    } else {
        gradient = ctx.createLinearGradient(0, 0, ctx.canvas.width, 0);
    }
    
    gradient.addColorStop(0, colorStart);
    gradient.addColorStop(1, colorEnd);
    
    return gradient;
}

/**
 * Update chart with new data
 * @param {Chart} chart - Chart.js instance to update
 * @param {Array} labels - New labels for x-axis
 * @param {Array} data - New data points
 * @param {number} datasetIndex - Index of dataset to update (default 0)
 */
function updateChart(chart, labels, data, datasetIndex = 0) {
    chart.data.labels = labels;
    chart.data.datasets[datasetIndex].data = data;
    chart.update();
}

/**
 * Create a health risk indicator chart (donut chart)
 * @param {string} canvasId - Canvas element ID
 * @param {number} riskScore - Risk score (0-10)
 * @param {string} riskLabel - Label for the risk
 * @param {string} color - Color for the risk indicator
 * @returns {Chart} Chart.js instance
 */
function createRiskChart(canvasId, riskScore, riskLabel, color = '#dc3545') {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return null;
    
    const ctx = canvas.getContext('2d');
    const normalizedScore = Math.min(Math.max(riskScore, 0), 10) / 10;
    
    const chartData = {
        labels: [riskLabel, ''],
        datasets: [{
            data: [normalizedScore * 100, (1 - normalizedScore) * 100],
            backgroundColor: [color, '#2c3034'],
            borderWidth: 0,
            cutout: '75%'
        }]
    };
    
    const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                enabled: false
            }
        }
    };
    
    return new Chart(ctx, createChartConfig('doughnut', chartData, options));
}

/**
 * Format number values with appropriate units for health metrics
 * @param {number} value - The value to format
 * @param {string} metric - Type of health metric
 * @returns {string} Formatted value with units
 */
function formatHealthMetric(value, metric) {
    if (value === undefined || value === null) {
        return 'N/A';
    }
    
    switch (metric) {
        case 'weight':
            return `${value.toFixed(1)} kg`;
        case 'bloodPressure':
            return value;
        case 'activity':
            return `${value} min`;
        case 'sleep':
            return `${value.toFixed(1)} hrs`;
        case 'glucose':
            return `${value} mg/dL`;
        case 'bmi':
            return value.toFixed(1);
        default:
            return value.toString();
    }
}
