import logging
from typing import Dict, Any, Optional
import numpy as np

# Setup logging
logger = logging.getLogger(__name__)

def calculate_bmi(height_cm: float, weight_kg: float) -> float:
    """
    Calculate BMI (Body Mass Index)
    
    Args:
        height_cm: Height in centimeters
        weight_kg: Weight in kilograms
        
    Returns:
        BMI value (weight / height^2)
    """
    try:
        height_m = height_cm / 100  # Convert cm to meters
        bmi = weight_kg / (height_m * height_m)
        return round(bmi, 1)
    except (ValueError, ZeroDivisionError) as e:
        logger.error(f"Error calculating BMI: {str(e)}")
        return 0.0

def get_bmi_category(bmi: float) -> str:
    """
    Get BMI category based on BMI value
    
    Args:
        bmi: BMI value
        
    Returns:
        BMI category as string
    """
    if bmi < 18.5:
        return "Underweight"
    elif bmi < 25:
        return "Normal weight"
    elif bmi < 30:
        return "Overweight"
    elif bmi < 35:
        return "Obesity Class I"
    elif bmi < 40:
        return "Obesity Class II"
    else:
        return "Obesity Class III"

def assess_diabetes_risk(user_data: Dict[str, Any]) -> float:
    """
    Assess diabetes risk on a scale of 0-10
    This is a simplified model based on common risk factors
    
    Args:
        user_data: Dictionary containing user health data
        
    Returns:
        Risk score from 0-10
    """
    try:
        risk_score = 0.0
        
        # Age is a risk factor
        age = user_data.get('age', 0)
        if age > 45:
            risk_score += 2.0
        elif age > 35:
            risk_score += 1.0
            
        # BMI is a risk factor
        bmi = user_data.get('bmi', 0)
        if bmi > 30:
            risk_score += 2.5
        elif bmi > 25:
            risk_score += 1.5
            
        # Family history
        if "diabetes" in user_data.get('family_history', '').lower():
            risk_score += 1.5
            
        # Physical activity
        activity = user_data.get('physical_activity', 'moderate').lower()
        if activity == 'sedentary' or activity == 'low':
            risk_score += 1.0
            
        # Already has diabetes
        if user_data.get('has_diabetes', False):
            risk_score = 10.0
            
        # Normalize to 0-10 scale
        risk_score = min(max(risk_score, 0.0), 10.0)
        
        return round(risk_score, 1)
        
    except Exception as e:
        logger.error(f"Error assessing diabetes risk: {str(e)}")
        return 0.0

def assess_heart_disease_risk(user_data: Dict[str, Any]) -> float:
    """
    Assess heart disease risk on a scale of 0-10
    This is a simplified model based on common risk factors
    
    Args:
        user_data: Dictionary containing user health data
        
    Returns:
        Risk score from 0-10
    """
    try:
        risk_score = 0.0
        
        # Age is a risk factor
        age = user_data.get('age', 0)
        if age > 65:
            risk_score += 2.5
        elif age > 45:
            risk_score += 1.5
            
        # Gender is a risk factor (males typically at higher risk)
        gender = user_data.get('gender', '').lower()
        if gender == 'male':
            risk_score += 0.5
            
        # BMI is a risk factor
        bmi = user_data.get('bmi', 0)
        if bmi > 30:
            risk_score += 1.5
        elif bmi > 25:
            risk_score += 1.0
            
        # Smoking is a major risk factor
        smoking = user_data.get('smoking_status', '').lower()
        if smoking == 'current':
            risk_score += 2.5
        elif smoking == 'former':
            risk_score += 1.0
            
        # Hypertension is a risk factor
        if user_data.get('has_hypertension', False):
            risk_score += 2.0
            
        # Family history
        if "heart" in user_data.get('family_history', '').lower():
            risk_score += 1.5
            
        # Already has heart disease
        if user_data.get('has_heart_disease', False):
            risk_score = 10.0
            
        # Normalize to 0-10 scale
        risk_score = min(max(risk_score, 0.0), 10.0)
        
        return round(risk_score, 1)
        
    except Exception as e:
        logger.error(f"Error assessing heart disease risk: {str(e)}")
        return 0.0

def assess_hypertension_risk(user_data: Dict[str, Any]) -> float:
    """
    Assess hypertension risk on a scale of 0-10
    This is a simplified model based on common risk factors
    
    Args:
        user_data: Dictionary containing user health data
        
    Returns:
        Risk score from 0-10
    """
    try:
        risk_score = 0.0
        
        # Age is a risk factor
        age = user_data.get('age', 0)
        if age > 65:
            risk_score += 2.0
        elif age > 45:
            risk_score += 1.0
            
        # BMI is a risk factor
        bmi = user_data.get('bmi', 0)
        if bmi > 30:
            risk_score += 2.0
        elif bmi > 25:
            risk_score += 1.0
            
        # Salt intake (approximated by diet type)
        diet = user_data.get('diet_type', '').lower()
        if 'high salt' in diet or 'processed' in diet:
            risk_score += 1.5
            
        # Physical activity
        activity = user_data.get('physical_activity', 'moderate').lower()
        if activity == 'sedentary' or activity == 'low':
            risk_score += 1.0
            
        # Stress level
        stress = user_data.get('stress_level', 5)
        if stress > 7:
            risk_score += 1.0
            
        # Already has hypertension
        if user_data.get('has_hypertension', False):
            risk_score = 10.0
            
        # Normalize to 0-10 scale
        risk_score = min(max(risk_score, 0.0), 10.0)
        
        return round(risk_score, 1)
        
    except Exception as e:
        logger.error(f"Error assessing hypertension risk: {str(e)}")
        return 0.0

def assess_obesity_risk(user_data: Dict[str, Any]) -> float:
    """
    Assess obesity risk or current status on a scale of 0-10
    
    Args:
        user_data: Dictionary containing user health data
        
    Returns:
        Risk score from 0-10
    """
    try:
        risk_score = 0.0
        
        # BMI is the primary indicator
        bmi = user_data.get('bmi', 0)
        if bmi >= 40:
            risk_score = 10.0  # Class III obesity
        elif bmi >= 35:
            risk_score = 8.0   # Class II obesity
        elif bmi >= 30:
            risk_score = 6.0   # Class I obesity
        elif bmi >= 25:
            risk_score = 4.0   # Overweight
        elif bmi >= 18.5:
            risk_score = 1.0   # Normal weight
        else:
            risk_score = 0.5   # Underweight
            
        # Adjust based on physical activity
        activity = user_data.get('physical_activity', 'moderate').lower()
        if activity == 'sedentary':
            risk_score = min(risk_score + 1.0, 10.0)
        elif activity == 'low':
            risk_score = min(risk_score + 0.5, 10.0)
        elif activity == 'high':
            risk_score = max(risk_score - 0.5, 0.0)
            
        # Diet influence
        diet = user_data.get('diet_type', '').lower()
        if 'processed' in diet or 'high calorie' in diet:
            risk_score = min(risk_score + 1.0, 10.0)
            
        return round(risk_score, 1)
        
    except Exception as e:
        logger.error(f"Error assessing obesity risk: {str(e)}")
        return 0.0

def calculate_risk_reduction(old_risk: float, new_risk: float) -> float:
    """
    Calculate the percentage of risk reduction
    
    Args:
        old_risk: Previous risk score
        new_risk: Current risk score
        
    Returns:
        Percentage reduction (positive means improvement)
    """
    if old_risk == 0:
        return 0.0
        
    reduction = ((old_risk - new_risk) / old_risk) * 100
    return round(reduction, 1)

def get_health_recommendation_by_risk(risk_type: str, risk_score: float) -> str:
    """
    Get a generic health recommendation based on risk type and score
    
    Args:
        risk_type: Type of health risk (diabetes, heart_disease, etc.)
        risk_score: Numeric risk score from 0-10
        
    Returns:
        Health recommendation as string
    """
    # Low risk
    if risk_score < 3:
        recommendations = {
            "diabetes": "Continue healthy eating habits. Include regular physical activity.",
            "heart_disease": "Maintain a heart-healthy diet low in saturated fats. Regular cardiovascular exercise is beneficial.",
            "hypertension": "Keep sodium intake moderate. Regular blood pressure checks are recommended.",
            "obesity": "Maintain your healthy weight through balanced diet and regular activity."
        }
    # Moderate risk
    elif risk_score < 7:
        recommendations = {
            "diabetes": "Consider reducing refined carbohydrate intake. Regular blood glucose monitoring may be beneficial.",
            "heart_disease": "Focus on heart-healthy diet, regular exercise, and stress management.",
            "hypertension": "Reduce sodium intake and consider DASH diet. Monitor blood pressure regularly.",
            "obesity": "Focus on portion control and increase physical activity to at least 150 minutes per week."
        }
    # High risk
    else:
        recommendations = {
            "diabetes": "Consult with healthcare provider about diabetes prevention plan. Regular glucose monitoring recommended.",
            "heart_disease": "Consult with a cardiologist. Focus on heart-healthy lifestyle including diet, exercise, and stress management.",
            "hypertension": "Consult with healthcare provider about blood pressure management. Consider DASH diet and sodium restriction.",
            "obesity": "Consider consulting with a nutritionist and healthcare provider for a personalized weight management plan."
        }
    
    return recommendations.get(risk_type, "Consult with a healthcare professional for personalized advice.")
