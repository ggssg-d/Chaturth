#!/usr/bin/env python
"""
Initialize the database for the Health Coaching app.
This script creates all tables and initial data.
"""
import os
import sys
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Add the SalesSyncPro directory to the Python path
salesync_path = os.path.join(os.getcwd(), 'SalesSyncPro')
if salesync_path not in sys.path:
    sys.path.insert(0, salesync_path)

try:
    # Import from the SalesSyncPro directory
    from SalesSyncPro.app import app, db
    import models  # This should be in the root directory
    
    logger.info("Imported app modules successfully")
except ImportError as e:
    logger.error(f"Error importing files: {e}")
    print(f"Error importing files: {e}")
    print("Make sure app.py exists in the SalesSyncPro directory and models.py exists in the root directory")
    sys.exit(1)

def init_db():
    """Initialize the database by creating tables and adding initial data."""
    logger.info("Starting database initialization...")
    
    with app.app_context():
        # Create all tables
        db.create_all()
        logger.info("Database tables created successfully")
        
        # Check if we need to create an admin user
        admin_exists = models.User.query.filter_by(username='admin').first() is not None
        
        if not admin_exists:
            from werkzeug.security import generate_password_hash
            # Create admin user
            admin = models.User(
                username='admin',
                email='admin@example.com',
                password_hash=generate_password_hash('admin123')
            )
            db.session.add(admin)
            db.session.commit()
            logger.info("Admin user created")
            
        # Display success message
        logger.info("Database initialization completed successfully")
        print("Database initialization completed successfully.")

if __name__ == "__main__":
    init_db()