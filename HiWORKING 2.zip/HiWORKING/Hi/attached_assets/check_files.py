import os

print("Current working directory:", os.getcwd())
print("\nFiles in current directory:")
for file in os.listdir('.'):
    print(f"- {file}")

print("\nChecking for nested SalesSyncPro directory:")
if os.path.exists('SalesSyncPro'):
    print("SalesSyncPro directory exists. Files inside:")
    for file in os.listdir('SalesSyncPro'):
        print(f"- {file}")
else:
    print("No SalesSyncPro nested directory found.")