import os
import logging
from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from SalesSyncPro.app import db
from models import User, HealthProfile, Recommendation, ProgressLog
from agents import HealthCoachAgentSystem

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize the health coach agent system
health_coach_system = HealthCoachAgentSystem()

# Initialize login manager
login_manager = LoginManager()

def register_routes(app):
    """Register all routes with the Flask application"""
    
    # Set up login manager
    login_manager.init_app(app)
    login_manager.login_view = 'login'
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    @app.route('/')
    def index():
        """Homepage route"""
        return render_template('index.html')
    
    @app.route('/register', methods=['GET', 'POST'])
    def register():
        """User registration route"""
        if request.method == 'POST':
            username = request.form.get('username')
            email = request.form.get('email')
            password = request.form.get('password')
            
            # Basic validation
            if not username or not email or not password:
                flash('All fields are required', 'danger')
                return redirect(url_for('register'))
            
            # Check if user already exists
            existing_user = User.query.filter_by(username=username).first()
            if existing_user:
                flash('Username already exists', 'danger')
                return redirect(url_for('register'))
            
            existing_email = User.query.filter_by(email=email).first()
            if existing_email:
                flash('Email already registered', 'danger')
                return redirect(url_for('register'))
            
            # Create new user
            new_user = User(
                username=username,
                email=email,
                password_hash=generate_password_hash(password)
            )
            
            db.session.add(new_user)
            db.session.commit()
            
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        
        return render_template('index.html', show_register=True)
    
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        """User login route"""
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            
            # Basic validation
            if not username or not password:
                flash('All fields are required', 'danger')
                return redirect(url_for('login'))
            
            # Find user
            user = User.query.filter_by(username=username).first()
            
            # Check password
            if user and check_password_hash(user.password_hash, password):
                login_user(user)
                flash('Login successful!', 'success')
                
                # Check if user has a health profile
                if user.profile:
                    return redirect(url_for('dashboard'))
                else:
                    return redirect(url_for('intake'))
            else:
                flash('Invalid username or password', 'danger')
                return redirect(url_for('login'))
        
        return render_template('index.html', show_login=True)
    
    @app.route('/logout')
    @login_required
    def logout():
        """User logout route"""
        logout_user()
        flash('You have been logged out', 'info')
        return redirect(url_for('index'))
    
    @app.route('/intake', methods=['GET', 'POST'])
    @login_required
    def intake():
        """Health profile intake form route"""
        # Check if user already has a profile
        existing_profile = HealthProfile.query.filter_by(user_id=current_user.id).first()
        
        if request.method == 'POST':
            # Extract form data
            try:
                # Basic information
                age = int(request.form.get('age', 0))
                gender = request.form.get('gender', '')
                height = float(request.form.get('height', 0))  # in cm
                weight = float(request.form.get('weight', 0))  # in kg
                
                # Medical history
                has_diabetes = 'diabetes' in request.form
                has_hypertension = 'hypertension' in request.form
                has_heart_disease = 'heart_disease' in request.form
                family_history = request.form.get('family_history', '')
                
                # Lifestyle factors
                smoking_status = request.form.get('smoking_status', '')
                alcohol_consumption = request.form.get('alcohol_consumption', '')
                physical_activity = request.form.get('physical_activity', '')
                diet_type = request.form.get('diet_type', '')
                stress_level = int(request.form.get('stress_level', 5))
                sleep_hours = float(request.form.get('sleep_hours', 7))
                
                # Compile user data for processing
                user_data = {
                    'age': age,
                    'gender': gender,
                    'height': height,
                    'weight': weight,
                    'has_diabetes': has_diabetes,
                    'has_hypertension': has_hypertension,
                    'has_heart_disease': has_heart_disease,
                    'family_history': family_history,
                    'smoking_status': smoking_status,
                    'alcohol_consumption': alcohol_consumption,
                    'physical_activity': physical_activity,
                    'diet_type': diet_type,
                    'stress_level': stress_level,
                    'sleep_hours': sleep_hours
                }
                
                # Process data with AI agents
                processed_data = health_coach_system.process_intake_form(user_data)
                
                if 'error' in processed_data:
                    flash(f"Error processing health data: {processed_data['error']}", 'danger')
                    return redirect(url_for('intake'))
                
                # Save or update health profile
                if existing_profile:
                    # Update existing profile
                    for key, value in processed_data.items():
                        if hasattr(existing_profile, key) and key != 'recommendations':
                            setattr(existing_profile, key, value)
                    
                    db.session.commit()
                    profile = existing_profile
                else:
                    # Create new profile
                    profile = HealthProfile(
                        user_id=current_user.id,
                        age=age,
                        gender=gender,
                        height=height,
                        weight=weight,
                        has_diabetes=has_diabetes,
                        has_hypertension=has_hypertension,
                        has_heart_disease=has_heart_disease,
                        family_history=family_history,
                        smoking_status=smoking_status,
                        alcohol_consumption=alcohol_consumption,
                        physical_activity=physical_activity,
                        diet_type=diet_type,
                        stress_level=stress_level,
                        sleep_hours=sleep_hours,
                        diabetes_risk=processed_data.get('diabetes_risk', 0),
                        heart_disease_risk=processed_data.get('heart_disease_risk', 0),
                        hypertension_risk=processed_data.get('hypertension_risk', 0),
                        obesity_risk=processed_data.get('obesity_risk', 0)
                    )
                    
                    db.session.add(profile)
                    db.session.commit()
                
                # Save recommendations
                if 'recommendations' in processed_data:
                    for rec_data in processed_data['recommendations']:
                        recommendation = Recommendation(
                            user_id=current_user.id,
                            category=rec_data.get('category', 'general'),
                            title=rec_data.get('title', ''),
                            description=rec_data.get('description', ''),
                            priority=rec_data.get('priority', 5),
                            agent_id=rec_data.get('agent_id', 'RecommendationAgent')
                        )
                        db.session.add(recommendation)
                    
                    db.session.commit()
                
                flash('Health profile updated successfully!', 'success')
                return redirect(url_for('dashboard'))
                
            except Exception as e:
                logger.error(f"Error processing intake form: {str(e)}")
                flash(f"Error processing form: {str(e)}", 'danger')
                return redirect(url_for('intake'))
        
        # For GET request, show the form with any existing data
        return render_template('intake.html', profile=existing_profile)
    
    @app.route('/dashboard')
    @login_required
    def dashboard():
        """User dashboard showing health metrics and recommendations"""
        # Get user profile
        profile = HealthProfile.query.filter_by(user_id=current_user.id).first()
        
        if not profile:
            flash('Please complete your health profile first', 'warning')
            return redirect(url_for('intake'))
        
        # Get recommendations
        recommendations = Recommendation.query.filter_by(user_id=current_user.id).order_by(Recommendation.priority.desc()).all()
        
        # Get progress logs for charts
        progress_logs = ProgressLog.query.filter_by(user_id=current_user.id).order_by(ProgressLog.log_date).all()
        
        # Prepare data for charts
        chart_dates = [log.log_date.strftime('%Y-%m-%d') for log in progress_logs]
        weights = [log.weight for log in progress_logs]
        bp_systolic = [log.blood_pressure_systolic for log in progress_logs]
        bp_diastolic = [log.blood_pressure_diastolic for log in progress_logs]
        activities = [log.physical_activity_minutes for log in progress_logs]
        sleep = [log.sleep_hours for log in progress_logs]
        
        return render_template(
            'dashboard.html', 
            profile=profile,
            recommendations=recommendations,
            chart_dates=chart_dates,
            weights=weights,
            bp_systolic=bp_systolic,
            bp_diastolic=bp_diastolic,
            activities=activities,
            sleep=sleep
        )
    
    @app.route('/recommendations')
    @login_required
    def recommendations():
        """View all recommendations"""
        recommendations = Recommendation.query.filter_by(user_id=current_user.id).order_by(Recommendation.priority.desc()).all()
        
        return render_template('recommendations.html', recommendations=recommendations)
    
    @app.route('/recommendation/<int:id>/complete', methods=['POST'])
    @login_required
    def complete_recommendation(id):
        """Mark a recommendation as completed"""
        recommendation = Recommendation.query.get_or_404(id)
        
        # Verify ownership
        if recommendation.user_id != current_user.id:
            flash('Unauthorized access', 'danger')
            return redirect(url_for('recommendations'))
        
        recommendation.completed = True
        recommendation.completed_at = datetime.utcnow()
        db.session.commit()
        
        flash('Recommendation marked as completed!', 'success')
        return redirect(url_for('recommendations'))
    
    @app.route('/progress', methods=['GET', 'POST'])
    @login_required
    def progress():
        """Log and view progress"""
        if request.method == 'POST':
            try:
                # Extract form data
                weight = float(request.form.get('weight', 0)) if request.form.get('weight') else None
                bp_systolic = int(request.form.get('bp_systolic', 0)) if request.form.get('bp_systolic') else None
                bp_diastolic = int(request.form.get('bp_diastolic', 0)) if request.form.get('bp_diastolic') else None
                glucose = float(request.form.get('glucose', 0)) if request.form.get('glucose') else None
                activity = int(request.form.get('activity', 0)) if request.form.get('activity') else None
                sleep = float(request.form.get('sleep', 0)) if request.form.get('sleep') else None
                stress = int(request.form.get('stress', 5)) if request.form.get('stress') else None
                mood = request.form.get('mood', '')
                notes = request.form.get('notes', '')
                
                # Create new progress log
                progress_log = ProgressLog(
                    user_id=current_user.id,
                    weight=weight,
                    blood_pressure_systolic=bp_systolic,
                    blood_pressure_diastolic=bp_diastolic,
                    glucose_level=glucose,
                    physical_activity_minutes=activity,
                    sleep_hours=sleep,
                    stress_level=stress,
                    mood=mood,
                    notes=notes
                )
                
                db.session.add(progress_log)
                db.session.commit()
                
                # Get profile for risk updates
                profile = HealthProfile.query.filter_by(user_id=current_user.id).first()
                
                # Update weight in profile if provided
                if weight and profile:
                    profile.weight = weight
                    db.session.commit()
                
                # Compile progress data for AI processing
                profile_data = {
                    'age': profile.age,
                    'gender': profile.gender,
                    'height': profile.height,
                    'weight': profile.weight,
                    'bmi': profile.weight / ((profile.height/100) ** 2) if profile.weight and profile.height else None,
                    'has_diabetes': profile.has_diabetes,
                    'has_hypertension': profile.has_hypertension,
                    'has_heart_disease': profile.has_heart_disease,
                    'diabetes_risk': profile.diabetes_risk,
                    'heart_disease_risk': profile.heart_disease_risk,
                    'hypertension_risk': profile.hypertension_risk,
                    'obesity_risk': profile.obesity_risk
                }
                
                # Get previous logs for comparison
                prev_logs = ProgressLog.query.filter_by(user_id=current_user.id).order_by(ProgressLog.log_date.desc()).limit(2).all()
                weight_change = None
                if len(prev_logs) > 1 and prev_logs[1].weight:
                    weight_change = weight - prev_logs[1].weight if weight else None
                
                progress_data = {
                    'weight': weight,
                    'weight_change': weight_change,
                    'blood_pressure': f"{bp_systolic}/{bp_diastolic}" if bp_systolic and bp_diastolic else None,
                    'glucose_level': glucose,
                    'physical_activity_minutes': activity,
                    'sleep_hours': sleep,
                    'stress_level': stress,
                    'mood': mood
                }
                
                # Get feedback from AI system
                feedback_data = health_coach_system.get_progress_feedback(profile_data, progress_data)
                
                if 'error' in feedback_data:
                    flash(f"Error processing progress data: {feedback_data['error']}", 'warning')
                else:
                    # Save new recommendations if any
                    if 'new_recommendations' in feedback_data:
                        for rec_data in feedback_data['new_recommendations']:
                            # Check if similar recommendation already exists
                            existing = Recommendation.query.filter_by(
                                user_id=current_user.id,
                                category=rec_data.get('category'),
                                title=rec_data.get('title')
                            ).first()
                            
                            if not existing:
                                recommendation = Recommendation(
                                    user_id=current_user.id,
                                    category=rec_data.get('category', 'general'),
                                    title=rec_data.get('title', ''),
                                    description=rec_data.get('description', ''),
                                    priority=rec_data.get('priority', 5),
                                    agent_id=rec_data.get('agent_id', 'FollowupAgent')
                                )
                                db.session.add(recommendation)
                        
                        db.session.commit()
                
                flash('Progress logged successfully!', 'success')
                
                # Store feedback in session for display
                if 'feedback' in feedback_data:
                    session['progress_feedback'] = feedback_data['feedback']
                
                return redirect(url_for('progress'))
                
            except Exception as e:
                logger.error(f"Error logging progress: {str(e)}")
                flash(f"Error logging progress: {str(e)}", 'danger')
                return redirect(url_for('progress'))
        
        # For GET request, show the form and previous logs
        logs = ProgressLog.query.filter_by(user_id=current_user.id).order_by(ProgressLog.log_date.desc()).all()
        
        # Get feedback from session if any
        feedback = session.pop('progress_feedback', None)
        
        return render_template('progress.html', logs=logs, feedback=feedback)
    
    @app.route('/profile')
    @login_required
    def profile():
        """View user profile"""
        health_profile = HealthProfile.query.filter_by(user_id=current_user.id).first()
        
        return render_template('profile.html', user=current_user, profile=health_profile)
    
    @app.route('/api/recommendation/<int:id>/complete', methods=['POST'])
    @login_required
    def api_complete_recommendation(id):
        """API endpoint to mark recommendation as completed"""
        recommendation = Recommendation.query.get_or_404(id)
        
        # Verify ownership
        if recommendation.user_id != current_user.id:
            return jsonify({'success': False, 'message': 'Unauthorized access'}), 403
        
        recommendation.completed = True
        recommendation.completed_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'success': True})
    
    # Error handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('index.html', error="Page not found"), 404
    
    @app.errorhandler(500)
    def server_error(e):
        return render_template('index.html', error="Internal server error"), 500
