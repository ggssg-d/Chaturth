#!/usr/bin/env python
"""
Initialize the database for the Health Coaching app.
This script creates all tables and initial data.
"""
import os
import sys
import logging
import sqlite3

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_database():
    """Create database tables directly using SQL."""
    logger.info("Starting database initialization...")
    
    # Create SQLite database file
    db_file = os.path.join(os.getcwd(), 'instance', 'health_coach.db')
    os.makedirs(os.path.dirname(db_file), exist_ok=True)
    
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    
    # Create User table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS user (
        id INTEGER PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    # Create HealthProfile table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS health_profile (
        id INTEGER PRIMARY KEY,
        user_id INTEGER NOT NULL,
        age INTEGER,
        gender TEXT,
        height REAL,
        weight REAL,
        has_diabetes BOOLEAN DEFAULT 0,
        has_hypertension BOOLEAN DEFAULT 0,
        has_heart_disease BOOLEAN DEFAULT 0,
        family_history TEXT,
        smoking_status TEXT,
        alcohol_consumption TEXT,
        physical_activity TEXT,
        diet_type TEXT,
        stress_level INTEGER,
        sleep_hours REAL,
        diabetes_risk REAL,
        heart_disease_risk REAL,
        hypertension_risk REAL,
        obesity_risk REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES user (id)
    )
    ''')
    
    # Create Recommendation table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS recommendation (
        id INTEGER PRIMARY KEY,
        user_id INTEGER NOT NULL,
        category TEXT,
        title TEXT,
        description TEXT,
        priority INTEGER,
        agent_id TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        completed BOOLEAN DEFAULT 0,
        completed_at TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES user (id)
    )
    ''')
    
    # Create ProgressLog table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS progress_log (
        id INTEGER PRIMARY KEY,
        user_id INTEGER NOT NULL,
        log_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        weight REAL,
        blood_pressure_systolic INTEGER,
        blood_pressure_diastolic INTEGER,
        glucose_level REAL,
        physical_activity_minutes INTEGER,
        sleep_hours REAL,
        stress_level INTEGER,
        notes TEXT,
        mood TEXT,
        FOREIGN KEY (user_id) REFERENCES user (id)
    )
    ''')
    
    # Check if admin user exists
    cursor.execute("SELECT id FROM user WHERE username = 'admin'")
    admin_exists = cursor.fetchone() is not None
    
    if not admin_exists:
        # Import werkzeug for password hashing (should be installed if flask is installed)
        from werkzeug.security import generate_password_hash
        
        # Create admin user
        cursor.execute(
            "INSERT INTO user (username, email, password_hash) VALUES (?, ?, ?)",
            ('admin', 'admin@example.com', generate_password_hash('admin123'))
        )
        logger.info("Admin user created")
    
    # Commit changes and close connection
    conn.commit()
    conn.close()
    
    logger.info("Database initialization completed successfully")
    print("Database initialization completed successfully.")

if __name__ == "__main__":
    create_database()