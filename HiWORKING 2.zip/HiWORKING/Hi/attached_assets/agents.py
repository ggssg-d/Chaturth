import os
import logging
import autogen
from typing import Dict, List, Any, Optional
import numpy as np
import pandas as pd
from health_utils import calculate_bmi, assess_diabetes_risk, assess_heart_disease_risk, assess_hypertension_risk, assess_obesity_risk

# Setup logging
logger = logging.getLogger(__name__)

# Configuration for the agents
api_key = os.environ.get("OPENAI_API_KEY", "")
valid_api_key = api_key if api_key.startswith("sk-") else ""

# Check if we have a valid API key
use_mock = not valid_api_key
if use_mock:
    logger.warning("No valid OpenAI API key found. Using mock responses for agent system.")

config_list = [
    {
        "model": "gpt-3.5-turbo",  # Default model, would use gpt-4 in production
        "api_key": valid_api_key,
    }
]

class HealthCoachAgentSystem:
    """Main class to coordinate all health coaching agents"""
    
    def __init__(self):
        # Set up the agent configuration
        self.config_list = config_list
        self.llm_config = {
            "config_list": self.config_list,
            "seed": 42,
            "temperature": 0.7,
        }
        
        # Initialize the agents
        self._initialize_agents()
        logger.info("Health Coach Agent System initialized successfully")
    
    def _initialize_agents(self):
        """Initialize all the agents with their specific roles"""
        
        # User Proxy Agent - represents the human user
        self.user_proxy = autogen.UserProxyAgent(
            name="User",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=0,
            system_message="You are a human user seeking health coaching advice."
        )
        
        # Intake Agent - collects and organizes user health data
        self.intake_agent = autogen.AssistantAgent(
            name="IntakeAgent",
            system_message="""You are a health data intake specialist. Your role is to:
            1. Collect and organize health information from users
            2. Ensure data completeness and accuracy
            3. Ask follow-up questions for missing information
            4. Prepare data for risk analysis
            Be thorough but empathetic in your approach.""",
            llm_config=self.llm_config
        )
        
        # Risk Analysis Agent - assesses health risks
        self.risk_analysis_agent = autogen.AssistantAgent(
            name="RiskAnalysisAgent",
            system_message="""You are a health risk analysis specialist. Your role is to:
            1. Analyze user health data to identify chronic condition risks
            2. Calculate risk scores for diabetes, heart disease, hypertension, and obesity
            3. Identify key risk factors that contribute to overall health risks
            4. Communicate risk assessments in clear, non-alarming ways
            Base your analysis on established medical risk models.""",
            llm_config=self.llm_config
        )
        
        # Recommendation Agent - generates personalized health recommendations
        self.recommendation_agent = autogen.AssistantAgent(
            name="RecommendationAgent", 
            system_message="""You are a health recommendation specialist. Your role is to:
            1. Generate personalized lifestyle recommendations based on risk assessments
            2. Prioritize recommendations for maximum health impact
            3. Create actionable and realistic suggestions for diet, exercise, sleep, and stress management
            4. Consider user preferences and constraints when making recommendations
            Your recommendations should be evidence-based and achievable.""",
            llm_config=self.llm_config
        )
        
        # Follow-up Agent - tracks progress and provides motivation
        self.followup_agent = autogen.AssistantAgent(
            name="FollowupAgent",
            system_message="""You are a health coach follow-up specialist. Your role is to:
            1. Track user progress toward health goals
            2. Provide motivational feedback and encouragement
            3. Adjust recommendations based on progress
            4. Identify obstacles to progress and suggest solutions
            Be supportive and motivating in your communication.""",
            llm_config=self.llm_config
        )
        
        # Group chat for agent collaboration
        self.groupchat = autogen.GroupChat(
            agents=[self.user_proxy, self.intake_agent, self.risk_analysis_agent, 
                    self.recommendation_agent, self.followup_agent],
            messages=[],
            max_round=10
        )
        
        self.manager = autogen.GroupChatManager(groupchat=self.groupchat, llm_config=self.llm_config)
    
    def process_intake_form(self, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process the intake form data and generate initial risk assessments"""
        logger.info("Processing intake form for user")
        
        try:
            # Calculate BMI
            if user_data.get('height') and user_data.get('weight'):
                user_data['bmi'] = calculate_bmi(user_data['height'], user_data['weight'])
            else:
                user_data['bmi'] = None
            
            # Perform risk assessments
            user_data['diabetes_risk'] = assess_diabetes_risk(user_data)
            user_data['heart_disease_risk'] = assess_heart_disease_risk(user_data)
            user_data['hypertension_risk'] = assess_hypertension_risk(user_data)
            user_data['obesity_risk'] = assess_obesity_risk(user_data)
            
            # Check if we're using mock mode (no valid API key)
            if use_mock:
                logger.info("Using mock recommendations due to missing API key")
                # Generate default recommendations based on risk factors
                recommendations = []
                
                # Add diet recommendation if diabetes or obesity risk is high
                if user_data.get('diabetes_risk', 0) > 5 or user_data.get('obesity_risk', 0) > 5:
                    recommendations.append({
                        "category": "diet",
                        "title": "Adopt a balanced, low-carb diet",
                        "description": "Focus on whole foods, limit processed carbs, and increase fiber intake. Include plenty of vegetables, lean proteins, and healthy fats.",
                        "priority": 8,
                        "agent_id": "RecommendationAgent"
                    })
                
                # Add exercise recommendation if heart disease or hypertension risk is high
                if user_data.get('heart_disease_risk', 0) > 5 or user_data.get('hypertension_risk', 0) > 5:
                    recommendations.append({
                        "category": "exercise",
                        "title": "Increase regular cardiovascular exercise",
                        "description": "Aim for at least 150 minutes of moderate-intensity exercise per week, such as brisk walking, swimming, or cycling.",
                        "priority": 7,
                        "agent_id": "RecommendationAgent"
                    })
                
                # Add sleep recommendation if stress level is high
                if user_data.get('stress_level', 0) > 7:
                    recommendations.append({
                        "category": "sleep",
                        "title": "Improve sleep quality and duration",
                        "description": "Aim for 7-9 hours of quality sleep per night. Establish a regular sleep schedule and create a relaxing bedtime routine.",
                        "priority": 6,
                        "agent_id": "RecommendationAgent"
                    })
                
                # Always add a general health recommendation
                recommendations.append({
                    "category": "general",
                    "title": "Regular health check-ups",
                    "description": "Schedule regular check-ups with your healthcare provider to monitor your health status and risk factors.",
                    "priority": 5,
                    "agent_id": "RecommendationAgent"
                })
                
                user_data['recommendations'] = recommendations
                return user_data
            else:
                # Set the chat message for the agents to process
                message = f"""
                User health profile:
                - Age: {user_data.get('age')}
                - Gender: {user_data.get('gender')}
                - BMI: {user_data.get('bmi')}
                - Medical history: Diabetes: {user_data.get('has_diabetes')}, 
                                  Hypertension: {user_data.get('has_hypertension')}, 
                                  Heart disease: {user_data.get('has_heart_disease')}
                - Lifestyle: Smoking: {user_data.get('smoking_status')},
                            Alcohol: {user_data.get('alcohol_consumption')},
                            Physical activity: {user_data.get('physical_activity')},
                            Diet: {user_data.get('diet_type')}
                - Risk scores: Diabetes: {user_data.get('diabetes_risk')},
                             Heart disease: {user_data.get('heart_disease_risk')},
                             Hypertension: {user_data.get('hypertension_risk')},
                             Obesity: {user_data.get('obesity_risk')}
                
                Analyze this health profile, assess the risks, and provide initial recommendations.
                """
                
                # Set the message to the user proxy
                self.user_proxy.initiate_chat(self.manager, message=message)
                
                # Extract recommendations from the conversation
                recommendations = self._extract_recommendations_from_chat()
                user_data['recommendations'] = recommendations
                
                return user_data
            
        except Exception as e:
            logger.error(f"Error in processing intake form: {str(e)}")
            return {"error": str(e)}
    
    def _extract_recommendations_from_chat(self) -> List[Dict[str, Any]]:
        """Extract recommendations from the group chat conversation"""
        recommendations = []
        
        # Look for recommendation agent messages
        for message in self.groupchat.messages:
            if message.get("sender") == "RecommendationAgent":
                content = message.get("content", "")
                
                # Simple parsing - in production, this would be more robust
                if "recommendation:" in content.lower():
                    parts = content.split("recommendation:", 1)
                    if len(parts) > 1:
                        rec_text = parts[1].strip()
                        category = "general"
                        
                        if "diet" in rec_text.lower():
                            category = "diet"
                        elif "exercise" in rec_text.lower() or "physical" in rec_text.lower():
                            category = "exercise"
                        elif "sleep" in rec_text.lower():
                            category = "sleep"
                        elif "stress" in rec_text.lower():
                            category = "stress management"
                        
                        recommendations.append({
                            "category": category,
                            "title": rec_text[:50] + "..." if len(rec_text) > 50 else rec_text,
                            "description": rec_text,
                            "priority": 5,  # Default priority
                            "agent_id": "RecommendationAgent"
                        })
        
        # If no recommendations found, create a default one
        if not recommendations:
            recommendations.append({
                "category": "general",
                "title": "Follow up with a healthcare provider",
                "description": "Based on your profile, we recommend consulting with a healthcare provider for a comprehensive health assessment.",
                "priority": 8,
                "agent_id": "RecommendationAgent"
            })
            
        return recommendations
    
    def get_progress_feedback(self, user_data: Dict[str, Any], progress_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate feedback and updated recommendations based on progress data"""
        logger.info("Generating progress feedback")
        
        try:
            # Check if we're using mock mode (no valid API key)
            if use_mock:
                logger.info("Using mock progress feedback due to missing API key")
                
                # Generate a positive feedback message based on the progress data
                feedback = "Great job on your progress! "
                
                # Add specific feedback based on weight change
                if progress_data.get('weight_change'):
                    weight_change = float(progress_data.get('weight_change', 0))
                    if weight_change < 0:
                        feedback += f"You've lost {abs(weight_change)} kg, which is excellent progress. "
                    elif weight_change > 0:
                        feedback += f"You've gained {weight_change} kg. Let's focus on your nutrition this week. "
                    else:
                        feedback += "Your weight has remained stable. "
                
                # Add feedback based on physical activity
                if progress_data.get('physical_activity_minutes'):
                    activity_minutes = int(progress_data.get('physical_activity_minutes', 0))
                    if activity_minutes >= 150:
                        feedback += "You're meeting the recommended activity levels of 150+ minutes per week. Keep it up! "
                    elif activity_minutes >= 100:
                        feedback += "You're getting close to the recommended activity level. Try to add another session this week. "
                    else:
                        feedback += "Let's work on increasing your physical activity to at least 150 minutes per week. "
                
                # Add feedback based on sleep hours
                if progress_data.get('sleep_hours'):
                    sleep_hours = float(progress_data.get('sleep_hours', 0))
                    if sleep_hours >= 7 and sleep_hours <= 9:
                        feedback += "Your sleep duration is in the optimal range. Great job prioritizing rest! "
                    elif sleep_hours < 7:
                        feedback += "You might benefit from more sleep. Aim for 7-9 hours for optimal health. "
                    else:
                        feedback += "You're getting plenty of sleep, which is great for recovery. "
                
                # Generate some example recommendations based on the progress
                recommendations = []
                
                # Always include a motivation recommendation
                recommendations.append({
                    "category": "motivation",
                    "title": "Celebrate your progress",
                    "description": "Take time to acknowledge the positive changes you've made. Even small steps forward are worth celebrating.",
                    "priority": 5,
                    "agent_id": "FollowupAgent"
                })
                
                # Add a specific recommendation based on the progress data
                if progress_data.get('physical_activity_minutes', 0) < 150:
                    recommendations.append({
                        "category": "exercise",
                        "title": "Increase weekly activity",
                        "description": "Try adding 10 more minutes of activity each day to work toward the recommended 150 minutes per week.",
                        "priority": 7,
                        "agent_id": "FollowupAgent"
                    })
                
                # Add a sleep recommendation if needed
                if progress_data.get('sleep_hours', 0) < 7:
                    recommendations.append({
                        "category": "sleep",
                        "title": "Improve sleep routine",
                        "description": "Create a consistent bedtime routine and aim to go to bed 30 minutes earlier each night.",
                        "priority": 6,
                        "agent_id": "FollowupAgent"
                    })
                
                return {
                    "feedback": feedback.strip(),
                    "new_recommendations": recommendations
                }
            else:
                # Create a message for the follow-up agent
                message = f"""
                User's original health profile:
                - Age: {user_data.get('age')}
                - BMI: {user_data.get('bmi')}
                - Risk scores: Diabetes: {user_data.get('diabetes_risk')},
                             Heart disease: {user_data.get('heart_disease_risk')}
                
                Progress update:
                - Weight change: {progress_data.get('weight_change', 'No data')}
                - Blood pressure: {progress_data.get('blood_pressure', 'No data')}
                - Physical activity: {progress_data.get('physical_activity_minutes', 'No data')} minutes/week
                - Sleep: {progress_data.get('sleep_hours', 'No data')} hours/night
                - Mood: {progress_data.get('mood', 'No data')}
                
                Please provide motivational feedback and any recommendation adjustments based on this progress.
                """
                
                # Reset the group chat
                self.groupchat.messages = []
                
                # Set the message to the user proxy
                self.user_proxy.initiate_chat(self.manager, message=message)
                
                # Extract feedback from the conversation
                feedback = ""
                for message in self.groupchat.messages:
                    if message.get("sender") == "FollowupAgent":
                        feedback += message.get("content", "") + "\n\n"
                
                # Extract new recommendations
                recommendations = self._extract_recommendations_from_chat()
                
                return {
                    "feedback": feedback.strip(),
                    "new_recommendations": recommendations
                }
            
        except Exception as e:
            logger.error(f"Error in generating progress feedback: {str(e)}")
            return {"error": str(e)}
