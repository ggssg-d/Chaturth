import os
import sys

# Add the SalesSyncPro directory to the Python path
salesync_path = os.path.join(os.getcwd(), 'SalesSyncPro')
if salesync_path not in sys.path:
    sys.path.insert(0, salesync_path)

# Import app from SalesSyncPro
from SalesSyncPro.app import app  # noqa: F401
