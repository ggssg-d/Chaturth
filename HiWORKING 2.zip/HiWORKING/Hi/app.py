import os
from dotenv import load_dotenv
import logging

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix


# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class Base(DeclarativeBase):
    pass


db = SQLAlchemy(model_class=Base)
# Load environment variables before creating Flask app
load_dotenv()
logger.info("Environment variables loaded")

# create the app
app = Flask(__name__)
secret_key = os.environ.get("SESSION_SECRET")
if not secret_key:
    logger.error("SESSION_SECRET environment variable is not set!")
    raise RuntimeError("SESSION_SECRET environment variable is not set!")
app.secret_key = secret_key
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)  # needed for url_for to generate with https

# configure the database as SQLite for simplicity
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///health_coach.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# initialize the app with the extension
db.init_app(app)

with app.app_context():
    # Import models
    import models  # noqa: F401
    # Create database tables if they don't exist
    db.create_all()
    
    # Import and register routes
    from routes import register_routes
    register_routes(app)

logger.info("Application initialized")
